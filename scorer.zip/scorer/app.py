from distutils.log import info
from pickle import TRUE
from unittest import result
from colorama import Cursor
from django.shortcuts import redirect
from flask import Flask, render_template_string, send_from_directory, url_for
from flask_restful import Api, Resource, reqparse, abort, fields, marshal_with
from flask.templating import render_template
from flask import request
from flask_sqlalchemy import SQLAlchemy
import sqlalchemy
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy import false, select, create_engine 
import requests
import json
import unicodedata
import urllib.request

app = Flask(__name__, template_folder='tmp')
api = Api(app)


# Format: mysql://[username]:[password]@[host]:[port]/[database]'
app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql://root@localhost/CBT_NILAI'

engine = create_engine(app.config['SQLALCHEMY_DATABASE_URI'])
session = Session(engine, future=True)

db = SQLAlchemy(app)
class Tampilan (db.Model):
    __tablename__ = "Tampilan"

    id_siswa = db.Column(db.Integer, primary_key=True)
    nama = db.Column(db.String(100), nullable=False)
    nrp = db.Column(db.String(100), nullable=False)
    Fisika = db.Column(db.String(100), nullable=False)
    Kimia = db.Column(db.String(100), nullable=False)
    Matematika = db.Column(db.String(100), nullable=False)
    Biologi = db.Column(db.String(100), nullable=False)
    Agama = db.Column(db.String(100), nullable=False)
    Bahasa_Indonesia = db.Column(db.String(100), nullable=False)
    Bahasa_Inggris = db.Column(db.String(100), nullable=False)

tampilan_fields = {
    'id_siswa': fields.Integer,
    'nama': fields.String,
    'nrp': fields.String,
    'Fisika': fields.String,
    'Kimia': fields.String,
    'Matematika': fields.String,
    'Biologi': fields.String,
    'Agama': fields.String,
    'Bahasa_Indonesia': fields.String,
    'Bahasa_Inggris': fields.String,

}

@api.resource('/tampilan/', '/tampilan/<int:siswa_id>', '/tampilan/<string:nama_siswa>', '/tampilan/cari')
#@api.resource('/mata-pelajaran/', '/mata-pelajaran/?id=<int:mapel_id>')
class Tampilan_Resource(Resource):
    @marshal_with(tampilan_fields)
    def get(self,siswa_id=None, nama_siswa=None):
        if siswa_id and not nama_siswa:
            # yang ada siswa id tapi nggak ada nrpnya
            result = Tampilan.query.filter_by(id_siswa=siswa_id).all()
        elif not siswa_id and nama_siswa:
            #  ngga ada siswa id tapi ada nrpnya
            result = session.query(Tampilan).filter(Tampilan.nama.ilike('%' + nama_siswa + '%')).limit(20).all()

        
        elif not siswa_id and not nama_siswa:
            # klo nggak ada semua
             return Tampilan.query[:30]
        else:
            abort(404, message=f"Data Tidak ditemukan, masukkan dengan benar")
       
        return result



@app.route('/view/')
def all_view():
    url = f"http://127.0.0.1:5000/tampilan/"
    response = urllib.request.urlopen(url)
    data = response.read()
    res = json.loads(data)

    return render_template('index.html', info=res)

@app.route('/view/<int:id>')
def view_id (id=None):
    url = f"http://127.0.0.1:5000/tampilan/{id}"
    response = urllib.request.urlopen(url)
    data = response.read()                                                    
    res = json.loads(data)

    return render_template('cari_id.html', hasil=res)

@app.route('/view/<string:nama>')
def cari_nama (nama=None):
    nama = nama.replace(' ', "%20")
    print(nama)
    url = f"http://127.0.0.1:5000/tampilan/{nama}"
    response = urllib.request.urlopen(url)
    data = response.read()                                                    
    res = json.loads(data)

    return render_template('cari.html', hasil=res)

@app.route('/view/cari')
def cari ():
    url = f"http://127.0.0.1:5000/tampilan/cari"
    response = urllib.request.urlopen(url)
    data = response.read()                                                    
    res = json.loads(data)

    return render_template('cari.html', hasil=res)

@app.route('/search', methods = ['POST'])
def search ():
    if request.method == 'POST' :
        nama = request.form.get('search', False)

    return cari_nama(nama)

@app.route('/download')
def download ():
    #For windows you need to use drive name [ex: F:/Example.pdf]
   return send_from_directory(directory='file', path='hasil.csv', as_attachment=TRUE)






        
if __name__ == "__main__":
    app.run(port=5000, debug=True)
